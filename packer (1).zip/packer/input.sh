#!/bin/bash
echo "************* execute terraform init"
packer build customwindows.json